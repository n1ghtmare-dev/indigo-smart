#!/usr/bin/env python3
"""Local-only operator UI. No cloud services or third-party packages required."""
import argparse
import copy
import hashlib
import html
import json
import mimetypes
import shutil
import threading
from collections import OrderedDict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
from urllib.parse import urlsplit, unquote, quote
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
OPERATOR_RESULTS = ROOT / "results/operator"
MAX_OPERATOR_RUNS = 12
MAX_ALTERNATIVE_CACHE_ENTRIES = 16
_ALTERNATIVE_SCREEN_CACHE = OrderedDict()
_ALTERNATIVE_CACHE_LOCK = threading.Lock()
sys.path.insert(0, str(ROOT))
from src.cosmo.case_data import load_dataset, load_json, scenario_named
from src.cosmo.case_engine import evaluate_plan
from src.cosmo.calendar import model_year, year_start
from src.cosmo.common import ZERO, decimal_time, json_value, number, time
from src.cosmo.exports import export_run, result_summary
from src.cosmo.planning import adapt_to_scenario, build_plan, reserve_emergency_capacity, STRATEGIES
from src.cosmo.research import extension_dataset


def operator_run_directories(root=OPERATOR_RESULTS):
    if not root.exists():
        return []
    return [path for path in root.iterdir()
            if path.is_dir() and not path.is_symlink() and len(path.name) == 32
            and all(ch in "0123456789abcdef" for ch in path.name)]


def prune_operator_runs(root=OPERATOR_RESULTS, keep=MAX_OPERATOR_RUNS):
    directories = sorted(operator_run_directories(root), key=lambda path: path.stat().st_mtime, reverse=True)
    removed = 0
    reclaimed = 0
    for path in directories[max(0, keep):]:
        reclaimed += sum(item.stat().st_size for item in path.rglob("*") if item.is_file())
        shutil.rmtree(path)
        removed += 1
    return {"removed": removed, "reclaimed_bytes": reclaimed, "remaining": min(len(directories), max(0, keep))}


def clear_operator_runs(root=OPERATOR_RESULTS):
    return prune_operator_runs(root, keep=0)


def result_diagnostics(result, data):
    issue = next((v for v in result.get("violations", []) if v.code == "STORAGE_OVERFLOW"), None)
    if issue is None:
        return {}
    arrivals = sorted((d for d in result.get("deliveries", [])
                       if d["actual_arrival_at"] == issue.at and d["gross_t"] > ZERO),
                      key=lambda d: (d["source"], d["id"]))
    storage = data.get("storage", {}).get(issue.subject, {})
    retained = 1 - number(storage.get("loss_rate_on_throughput", "0"))
    planned_reduction = issue.excess / retained if retained > ZERO else issue.excess
    return {"storage_overflow": {
        "at": issue.at,
        "year": model_year(issue.at),
        "active_storage": issue.subject,
        "excess_t": issue.excess,
        "required_planned_reduction_t": planned_reduction,
        "deliveries": [{"id": d["id"], "source": d["source"], "planned_t": d["planned_t"],
                        "gross_t": d["gross_t"]} for d in arrivals],
    }}


def inventory_timeline(result, data, plan):
    """Compact the daily physical trace into chart points without changing model precision."""
    trace = result.get("physical") or result.get("partial_physical") or {}
    intervals = trace.get("intervals", [])
    if not intervals:
        return {"points": [], "reserve_markers": [], "stopped_at": None}
    first_at = year_start(int(plan["first_year"]))
    last_at = year_start(int(plan["last_year"]) + 1)
    points, monthly, previous_storage = [], {}, None
    deliveries_by_at = {}
    for delivery in result.get("deliveries", []):
        delivered_at = time(delivery["actual_arrival_at"])
        gross = number(delivery.get("gross_t", "0"))
        if first_at <= delivered_at < last_at and gross > ZERO:
            deliveries_by_at.setdefault(delivered_at, []).append({
                "id": delivery["id"], "source": delivery["source"], "gross_t": gross
            })

    def capacity(row):
        return number(data["storage"][row["storage_id"]]["capacity_t"])

    def add(at, inventory, row, kind, arrival=ZERO, deliveries=None):
        point = {"at": decimal_time(at), "inventory_t": inventory,
                 "capacity_t": capacity(row), "storage_id": row["storage_id"],
                 "kind": kind, "arrival_t": arrival}
        if deliveries:
            point["deliveries"] = deliveries
        points.append(point)

    for row in intervals:
        at, until = time(row["at"]), time(row["until"])
        if until <= first_at or at >= last_at:
            continue
        cap = capacity(row)
        gross = number(row.get("gross_t", "0"))
        overflow = number(row["after_inflow_t"]) > cap
        if at == first_at or row["storage_id"] != previous_storage:
            add(at, row["opening_t"], row, "boundary")
        if gross > ZERO:
            add(at, row["opening_t"], row, "before_arrival")
            add(at, row["after_inflow_t"], row, "arrival", gross, deliveries_by_at.get(at))
        if not overflow:
            bucket = int(decimal_time(max(at, first_at) - first_at) // 30)
            monthly[bucket] = row
        previous_storage = row["storage_id"]

    for row in monthly.values():
        add(time(row["until"]), row["closing_t"], row, "sample")

    order = {"sample": 0, "boundary": 1, "before_arrival": 2, "arrival": 3}
    points.sort(key=lambda item: (item["at"], order[item["kind"]]))
    compact = []
    for point in points:
        signature = (point["at"], point["inventory_t"], point["capacity_t"], point["kind"])
        if not compact or signature != compact[-1][0]:
            compact.append((signature, point))

    annual = trace.get("annual", [])
    reserve_markers = [{"year": row["year"], "at": decimal_time(year_start(int(row["year"]))),
                        "required_reserve_t": row["required_reserve_t"]}
                       for row in annual
                       if int(plan["first_year"]) <= int(row["year"]) <= int(plan["last_year"])
                       and row.get("required_reserve_t") is not None]
    overflow = next((v for v in result.get("violations", []) if v.code == "STORAGE_OVERFLOW"), None)
    return {"points": [item[1] for item in compact], "reserve_markers": reserve_markers,
            "stopped_at": decimal_time(overflow.at) if overflow else None}


def build_package(options):
    previous = options.get("package")
    if previous and options.get("extension"):
        raise ValueError("Пример расширения открывается отдельно от текущего плана")
    if previous:
        if previous.get("reference_plan"):
            raise ValueError("Вернитесь к исходному плану перед перестроением")
        data = copy.deepcopy(previous["dataset"])
        # Validate the original case hashes even when building from edited inputs.
        from src.cosmo.case_data import validate_dataset
        validate_dataset(data, previous["plan"]["first_year"], previous["plan"]["last_year"])
        if data.get("scope") == "CASE_INPUT" and json_value(data) != json_value(load_dataset()):
            raise ValueError("Изменён контрольный набор; используйте исследовательскую копию")
        if len(data["sources"]) > 50:
            raise ValueError("Лимит интерфейса: 50 источников")
    else:
        data = extension_dataset() if options.get("extension") else load_dataset()
    strategy = options.get("strategy", "EARTH_NEW")
    if strategy not in STRATEGIES:
        raise ValueError("Неизвестная архитектура")
    reserve = str(options.get("reserve_days", "45"))
    if not 45 <= float(reserve) <= 120:
        raise ValueError("Планировщик поддерживает резерв от 45 до 120 дней")
    profile = options.get("profile", "BASE")
    if profile not in ("BASE", "LOW", "HIGH"):
        raise ValueError("Профиль: BASE, LOW или HIGH")
    plan = build_plan(strategy, reserve_days=reserve, profile=profile, dataset=data,
                      policy=previous["plan"]["policy"] if previous else None,
                      zbo=options.get("zbo", True),
                      last_year=previous["plan"]["last_year"] if previous else (2041 if options.get("extension") else 2040))
    if options.get("e_insurance", False):
        plan = reserve_emergency_capacity(plan, data)
    package = {"plan": plan, "dataset": data, "scenario": scenario_named(profile), "reference_plan": None}
    if previous and previous.get("ui_state") is not None:
        package["ui_state"] = copy.deepcopy(previous["ui_state"])
    return package


def active_strategy(plan):
    investments = {item["id"] for item in plan.get("investments", [])}
    if "EARTH_NEW" in investments and "LUNAR_ISRU" in investments:
        return "HYBRID"
    if "EARTH_NEW" in investments:
        return "EARTH_NEW"
    if "LUNAR_ISRU" in investments:
        return "LUNAR"
    return "EARTH_ONLY"


def comparison_summary(plan, data, scenario, result, reference=None):
    package = {"plan": plan, "dataset": data, "scenario": scenario, "reference_plan": reference}
    canonical = json.dumps(json_value(package), sort_keys=True, ensure_ascii=False,
                           separators=(",", ":")).encode()
    summary = result_summary(result)
    summary.update({"data_version": data.get("dataset_id"),
                    "policy_version": plan.get("policy", {}).get("policy_id"),
                    "calculated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "input_sha256": hashlib.sha256(canonical).hexdigest()})
    return summary


def compact_evaluation(plan, data, scenario, reference=None):
    result = evaluate_plan(plan, data, scenario, reference_plan=reference)
    years = sorted({str(v.subject) for v in result.get("violations", [])
                    if str(v.subject).isdigit() and 1900 <= int(v.subject) <= 2200})
    return {"summary": comparison_summary(plan, data, scenario, result, reference),
            "annual": result.get("annual", []),
            "violations": result.get("violations", []),
            "diagnostics": result_diagnostics(result, data),
            "components_mln": (result.get("economics") or {}).get("components_mln", {}),
            "violation_years": years}


def comparison_pair(plan, data, reference=None):
    return [{**compact_evaluation(plan, data, scenario_named(mode), reference),
             "scenario_mode": mode}
            for mode in ("BASE", "MANDATORY_STRESS")]


def _canonical_hash(value):
    canonical = json.dumps(json_value(value), sort_keys=True, ensure_ascii=False,
                           separators=(",", ":")).encode()
    return hashlib.sha256(canonical).hexdigest()


def _active_sources(plan):
    contract_sources = {item["source"] for item in plan.get("contracts", [])
                        if number(item.get("reserved_annual", "0")) > ZERO}
    contracts = {item["id"]: item for item in plan.get("contracts", [])}
    order_sources = {contracts[item["contract_id"]]["source"] for item in plan.get("orders", [])
                     if item.get("contract_id") in contracts and number(item.get("planned_t", "0")) > ZERO}
    return sorted(contract_sources | order_sources)


def _rejection_reason(evaluation):
    summary = evaluation["summary"]
    codes = {getattr(item, "code", None) if not isinstance(item, dict) else item.get("code")
             for item in evaluation.get("violations", [])}
    if summary.get("status") == "STOPPED_OVERFLOW" or "STORAGE_OVERFLOW" in codes:
        return "STORAGE_OVERFLOW", "переполнение склада"
    if (number(summary.get("shortage_t") or "0") > ZERO
            or codes & {"TOTAL_SERVICE_SHORTFALL", "CRITICAL_SERVICE_SHORTFALL", "OPENING_RESERVE_SHORTFALL"}):
        return "SHORTAGE_OR_SERVICE", "дефицит или недостаточный сервис"
    return "OTHER_CONSTRAINTS", "другие ограничения плана"


def _screen_cache_key(plan, data, scenario, profile):
    return _canonical_hash({"dataset": data, "policy": plan.get("policy"), "scenario": scenario,
                            "first_year": plan.get("first_year"), "last_year": plan.get("last_year"),
                            "planning_profile": profile})


def _cached_screen(plan, data, scenario, profile):
    key = _screen_cache_key(plan, data, scenario, profile)
    with _ALTERNATIVE_CACHE_LOCK:
        cached = _ALTERNATIVE_SCREEN_CACHE.get(key)
        if cached is not None:
            _ALTERNATIVE_SCREEN_CACHE.move_to_end(key)
            return copy.deepcopy(cached), True

    screened = feasible = 0
    rejection_counts = {}
    best_by_strategy = {}
    feasible_candidates = []
    for strategy in STRATEGIES:
        for reserve in (45, 50, 55, 60, 65, 70):
            screened += 1
            try:
                candidate = build_plan(strategy, reserve_days=str(reserve), profile=profile, dataset=data,
                                       policy=plan.get("policy"), zbo=True, last_year=plan["last_year"])
                evaluation = compact_evaluation(candidate, data, scenario)
                summary = evaluation["summary"]
                if summary["status"] != "FEASIBLE" or summary.get("pv_mln") is None:
                    code, label = _rejection_reason(evaluation)
                    entry = rejection_counts.setdefault(code, {"code": code, "label": label, "count": 0})
                    entry["count"] += 1
                    continue
                feasible += 1
                rank = (number(summary["pv_mln"]), number(summary["capex_mln"]), candidate["plan_id"])
                feasible_candidates.append({"strategy": strategy, "rank": rank, "reserve": reserve,
                                            "candidate": candidate, "evaluation": evaluation})
                previous = best_by_strategy.get(strategy)
                if previous is None or rank < previous["rank"]:
                    best_by_strategy[strategy] = {"rank": rank, "reserve": reserve,
                                                  "candidate": candidate, "evaluation": evaluation}
            except (ValueError, KeyError, ArithmeticError, TypeError):
                entry = rejection_counts.setdefault("INVALID_CANDIDATE", {
                    "code": "INVALID_CANDIDATE", "label": "противоречивые входы кандидата", "count": 0})
                entry["count"] += 1

    result = {"screened": screened, "feasible": feasible,
              "rejection_reasons": sorted(rejection_counts.values(), key=lambda item: (-item["count"], item["code"])),
              "candidates": sorted(feasible_candidates, key=lambda item: item["rank"]),
              "best": sorted(({"strategy": strategy, **entry} for strategy, entry in best_by_strategy.items()),
                             key=lambda item: item["rank"])}
    with _ALTERNATIVE_CACHE_LOCK:
        _ALTERNATIVE_SCREEN_CACHE[key] = copy.deepcopy(result)
        _ALTERNATIVE_SCREEN_CACHE.move_to_end(key)
        while len(_ALTERNATIVE_SCREEN_CACHE) > MAX_ALTERNATIVE_CACHE_ENTRIES:
            _ALTERNATIVE_SCREEN_CACHE.popitem(last=False)
    return result, False


def _is_strictly_better(candidate_summary, current_summary):
    """A feasible candidate beats an invalid plan, or a feasible plan on PV/CAPEX."""
    if candidate_summary.get("status") != "FEASIBLE" or candidate_summary.get("pv_mln") is None:
        return False
    if current_summary.get("status") != "FEASIBLE" or current_summary.get("pv_mln") is None:
        return True
    candidate_pv = number(candidate_summary["pv_mln"])
    current_pv = number(current_summary["pv_mln"])
    if candidate_pv != current_pv:
        return candidate_pv < current_pv
    candidate_capex = candidate_summary.get("capex_mln")
    current_capex = current_summary.get("capex_mln")
    return (candidate_capex is not None and current_capex is not None
            and number(candidate_capex) < number(current_capex))


def suggested_alternatives(plan, data, scenario, current_summary=None, ui_state=None):
    """Screen deterministic plans and explain the best feasible alternatives."""
    construction = plan.get("construction", {})
    scenario_id = scenario.get("scenario_id", "BASE")
    profile = scenario_id if scenario_id in ("BASE", "LOW", "HIGH") else construction.get("planning_profile", "BASE")
    if scenario_id == "MANDATORY_STRESS":
        profile = "HIGH"
    if profile not in ("BASE", "LOW", "HIGH"):
        profile = "BASE"
    current = json.dumps(json_value(plan), sort_keys=True, ensure_ascii=False)
    screen, cache_hit = _cached_screen(plan, data, scenario, profile)
    if current_summary is None:
        current_summary = compact_evaluation(plan, data, scenario)["summary"]
    current_sources = set(_active_sources(plan))
    current_reserve = number(construction.get("reserve_days", "0"))

    eligible = []
    seen_signatures = {current}
    for entry in screen.get("candidates", screen["best"]):
        candidate, evaluation = entry["candidate"], entry["evaluation"]
        signature = json.dumps(json_value(candidate), sort_keys=True, ensure_ascii=False)
        if signature in seen_signatures or not _is_strictly_better(evaluation["summary"], current_summary):
            continue
        seen_signatures.add(signature)
        eligible.append(entry)

    # Prefer different architectures, then fill the list with the next-best plan.
    selected = []
    selected_signatures = set()
    selected_strategies = set()
    for entry in eligible:
        if entry["strategy"] in selected_strategies:
            continue
        selected.append(entry)
        selected_strategies.add(entry["strategy"])
        selected_signatures.add(json.dumps(json_value(entry["candidate"]), sort_keys=True, ensure_ascii=False))
        if len(selected) == 2:
            break
    if len(selected) < 2:
        for entry in eligible:
            signature = json.dumps(json_value(entry["candidate"]), sort_keys=True, ensure_ascii=False)
            if signature in selected_signatures:
                continue
            selected.append(entry)
            selected_signatures.add(signature)
            if len(selected) == 2:
                break

    alternatives = []
    for entry in selected:
        strategy, reserve = entry["strategy"], entry["reserve"]
        candidate, evaluation = entry["candidate"], entry["evaluation"]
        package = {"plan": candidate, "dataset": copy.deepcopy(data),
                   "scenario": copy.deepcopy(scenario), "reference_plan": None}
        if ui_state is not None:
            package["ui_state"] = copy.deepcopy(ui_state)
        summary = evaluation["summary"]
        candidate_sources = set(_active_sources(candidate))
        pv_delta = (number(summary["pv_mln"]) - number(current_summary["pv_mln"])
                    if summary.get("pv_mln") is not None and current_summary.get("pv_mln") is not None else None)
        capex_delta = (number(summary["capex_mln"]) - number(current_summary["capex_mln"])
                       if summary.get("capex_mln") is not None and current_summary.get("capex_mln") is not None else None)
        alternatives.append({"id": f"ALT-{len(alternatives) + 1}",
                             "label": f"{STRATEGIES[strategy]['label']}, резерв {reserve} дней",
                             "strategy": strategy, "reserve_days": reserve,
                             "package": package, "evaluation": evaluation,
                             "comparison": comparison_pair(candidate, data),
                             "delta": {"pv_mln": pv_delta, "capex_mln": capex_delta,
                                       "reserve_days": number(reserve) - current_reserve,
                                       "added_sources": sorted(candidate_sources - current_sources),
                                       "removed_sources": sorted(current_sources - candidate_sources)}})
    return alternatives, {"screened_candidates": screen["screened"], "feasible_candidates": screen["feasible"],
                          "better_candidates": len(eligible),
                          "rejected_candidates": screen["screened"] - screen["feasible"],
                          "rejection_reasons": screen["rejection_reasons"], "cache_hit": cache_hit,
                          "planning_profile": profile, "scenario_id": scenario_id,
                          "selection_basis": "STRICTLY_BETTER_FEASIBLE_MIN_PV"}


def process_request(payload, output_root=None):
    action = payload.get("action")
    if action == "build":
        return {"package": build_package(payload)}
    if action not in ("evaluate", "adapt"):
        raise ValueError("Неизвестное действие")
    package = copy.deepcopy(payload["package"])
    plan, data = package["plan"], package["dataset"]
    if len(plan.get("orders", [])) > 4000 or len(plan.get("contracts", [])) > 500 or len(data.get("sources", {})) > 50:
        raise ValueError("Лимит интерфейса: 4000 заказов, 500 контрактов, 50 источников")
    mode = payload.get("scenario", "SAVED")
    scenario = package["scenario"] if mode == "SAVED" else scenario_named(mode)
    reference = package.get("reference_plan")
    if action == "adapt":
        if reference is not None:
            raise ValueError("Уже адаптированный план: откройте исходный пакет для новой реакции")
        reference = copy.deepcopy(plan)
        plan = adapt_to_scenario(plan, scenario, data)
    result = evaluate_plan(plan, data, scenario, reference_plan=reference)
    package = {"plan": plan, "dataset": data, "scenario": scenario, "reference_plan": reference}
    if payload["package"].get("ui_state") is not None:
        package["ui_state"] = copy.deepcopy(payload["package"]["ui_state"])
    run_id = uuid4().hex
    directory = (output_root or OPERATOR_RESULTS) / run_id
    summary = export_run(directory, plan, data, scenario, result, reference=reference, include_inventory=False)
    if output_root is None:
        prune_operator_runs()
    comparison = comparison_pair(plan, data, reference)
    for item in comparison:
        if item["summary"]["scenario_id"] == summary["scenario_id"]:
            item.update(summary=summary, annual=result.get("annual", []),
                        violations=result.get("violations", []), diagnostics=result_diagnostics(result, data),
                        components_mln=(result.get("economics") or {}).get("components_mln", {}),
                        run_url="/results/operator/" + run_id + "/")
    alternatives, alternatives_search = suggested_alternatives(
        plan, data, scenario, current_summary=summary, ui_state=package.get("ui_state"))
    return json_value({"package": package, "summary": summary, "annual": result.get("annual", []),
                       "inventory_timeline": inventory_timeline(result, data, plan),
                       "diagnostics": result_diagnostics(result, data),
                       "violations": result["violations"], "run_url": "/results/operator/" + run_id + "/",
                       "components_mln": (result.get("economics") or {}).get("components_mln", {}),
                       "scenario_mode": mode, "comparison": comparison,
                       "alternatives": alternatives, "alternatives_search": alternatives_search})


class Handler(BaseHTTPRequestHandler):
    server_version = "CosmoLocal/1.0"

    def allowed_host(self):
        return self.headers.get("Host") in (f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}")

    def reply(self, status, body, mime="application/json; charset=utf-8"):
        if not isinstance(body, bytes):
            body = json.dumps(json_value(body), ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.allowed_host():
            return self.reply(403, {"error": "Только локальный Host"})
        route = unquote(urlsplit(self.path).path)
        if route == "/api/default":
            path = ROOT / "results/project/selected-base/input-package.json"
            return self.reply(200, {"package": load_json(path) if path.exists() else build_package({})})
        if route == "/api/summary":
            path = ROOT / "results/project/summary.json"
            return self.reply(200, load_json(path)) if path.exists() else self.reply(404, {"error": "Сначала python3 scripts/run_project.py"})
        if route == "/":
            route = "/app/index.html"
        path = (ROOT / route.lstrip("/")).resolve()
        allowed = [ROOT / name for name in ("app", "docs", "results", "output", "configs", "data/reference", "data/original")]
        single_files = {ROOT / name for name in ("README.md", "data/source-manifest.json", "plan-keisa.html", "razbor-keisa.html")}
        if not (path in single_files or any(path.is_relative_to(folder) for folder in allowed)):
            return self.reply(404, {"error": "Файл не найден"})
        if path.is_dir():
            links = ''.join('<li><a href="/' + quote(str(child.relative_to(ROOT))) + ('/' if child.is_dir() else '') + '">' + html.escape(child.name) + '</a></li>' for child in sorted(path.iterdir()) if not child.is_symlink() and not child.name.startswith('.'))
            return self.reply(200, ('<!doctype html><html lang="ru"><meta charset="utf-8"><title>Файлы проекта</title><h1>Файлы проекта</h1><ul>'+links+'</ul></html>').encode(), 'text/html; charset=utf-8')
        if not path.is_file():
            return self.reply(404, {"error": "Файл не найден"})
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self.reply(200, path.read_bytes(), mime + ("; charset=utf-8" if mime.startswith("text/") else ""))

    def do_POST(self):
        if not self.allowed_host() or self.path not in ("/api/run", "/api/cleanup"):
            return self.reply(403, {"error": "Недопустимый локальный запрос"})
        origin = self.headers.get("Origin")
        if origin and origin not in (f"http://127.0.0.1:{self.server.server_port}", f"http://localhost:{self.server.server_port}"):
            return self.reply(403, {"error": "Межсайтовые запросы запрещены"})
        if self.headers.get_content_type() != "application/json":
            return self.reply(415, {"error": "Требуется application/json"})
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 4_000_000:
                return self.reply(413, {"error": "Размер пакета: не более 4 MB"})
            payload = json.loads(self.rfile.read(size))
            if self.path == "/api/cleanup":
                return self.reply(200, clear_operator_runs())
            result = process_request(payload)
            self.reply(200, result)
        except (ValueError, KeyError, TypeError, ArithmeticError, AttributeError) as exc:
            self.reply(400, {"error": f"Проверьте входы: {exc}"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"Cosmo operator: http://127.0.0.1:{server.server_port} (Ctrl+C to stop)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
